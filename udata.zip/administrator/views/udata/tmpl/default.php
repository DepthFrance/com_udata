<?php
/*------------------------------------------------------------------------
# default.php - uData Component
# ------------------------------------------------------------------------
# author    Thomas Portier
# copyright Copyright (C) 2014. All Rights Reserved
# license   Depth France
# website   www.depth.fr
-------------------------------------------------------------------------*/

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

?>
Accédez au paramétrage de l'outil via le bouton "paramètres".<br><br>
Cet outil a été développé par la société Depth : <a href="http://www.depth.fr" target="_blank">www.depth.fr</a><br><br>
