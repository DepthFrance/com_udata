<?php
/*------------------------------------------------------------------------
# udata.php - uData Component
# ------------------------------------------------------------------------
# author    Thomas Portier
# copyright Copyright (C) 2015. All Rights Reserved
# license   Depth France
# website   www.depth.fr
-------------------------------------------------------------------------*/

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * uData component helper
 */
abstract class UdataHelper
{
  const MAX_RESULTS = 1001;

       


}
